import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tips-recomendations',
  templateUrl: './tips-recomendations.component.html',
  styleUrls: ['./tips-recomendations.component.css']
})
export class TipsRecomendationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
