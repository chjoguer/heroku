export const environment = {
  production: true,
  apiUrl: "http://127.0.0.1:8000",
  imgUrl: "http://127.0.0.1:8000",
  //apiUrl: "http://chjoguer.pythonanywhere.com",
  //imgUrl: "http://chjoguer.pythonanywhere.com",


};
